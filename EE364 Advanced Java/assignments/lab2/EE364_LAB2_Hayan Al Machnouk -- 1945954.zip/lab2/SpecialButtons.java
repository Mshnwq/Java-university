package lab2;

public enum SpecialButtons {
    Space,
    Backspace,
    Enter
}
