package lab3_1_package;

public enum SpecialButtons {
    Space,
    Backspace,
    Enter
}
