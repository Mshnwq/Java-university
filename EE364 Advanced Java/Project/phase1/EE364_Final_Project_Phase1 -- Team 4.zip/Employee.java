package carFactory;

public interface Employee {
    public int employeeSalary = 0;
    int getSalary();
}
