package phase1;
/**
 * Class interface shows the value of employee salary
 */
public interface Employee {
    public int employeeSalary = 0;
    int getSalary();
}
